package com.infy.kone.pages;

import org.testng.Assert;

import com.infy.kone.objectRepository.LoginPage_Objects;
import com.infy.kone.utility.CommonMethods;

public class Login_page {

	CommonMethods commonMethods = new CommonMethods();
	
	public  void selectServer() {
		commonMethods.clickOnElement(LoginPage_Objects.three_dots);
		commonMethods.clickOnElement(LoginPage_Objects.change_server);
		commonMethods.clickOnElement(LoginPage_Objects.Test_server);
		commonMethods.clickOnElement(LoginPage_Objects.Apply_btn);
	}
	
	public void login() {
		String UserID =CommonMethods.prop.getProperty("UserID_Int");
		String Password = CommonMethods.prop.getProperty("Password_Int");
		
		commonMethods.enterValue(LoginPage_Objects.textbox_userName, UserID);
		commonMethods.enterValue(LoginPage_Objects.textbox_password, Password);
		commonMethods.clickOnElement(LoginPage_Objects.btn_login);
		
		
	}
	
	public void loginSuccessful() throws InterruptedException {
		commonMethods.sleepWait();
		boolean status =commonMethods.isElementDisplayed(LoginPage_Objects.text_sync);
		Assert.assertTrue(status, "Element not displayed !!");
		
		
		
		
	/*	commonMethods.clickElementIfVisible(LoginPage_Objects.btn_allowAccessLocation);
		commonMethods.clickElementIfVisible(LoginPage_Objects.switch_DNDPermission);
		commonMethods.clickElementIfVisible(LoginPage_Objects.btn_AllowDND);
		commonMethods.clickElementIfVisible(LoginPage_Objects.back_arrow);*/
		
		
	}
	
	
}
