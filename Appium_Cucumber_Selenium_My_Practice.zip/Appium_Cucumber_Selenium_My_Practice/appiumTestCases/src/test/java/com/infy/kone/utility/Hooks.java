package com.infy.kone.utility;



import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cucumber.listener.Reporter;
import com.google.common.io.Files;

public class Hooks {

	@Before
	public void beforeScenario() {
		CommonMethods.loadProperties();
		
		System.out.println("Prop file loaded successfully!!!!" + CommonMethods.prop.getProperty("browser_type"));
		
		File directory = new File(String.valueOf(System.getProperty("user.dir") + "/target/cucumber-reports/screenshots/"));

		 if(!directory.exists()){

			         System.out.println("Folder folder for screenshot is not created");
		             directory.mkdir();
		             System.out.println("Folder folder for screenshot is created successfully");
		 }
	}
	
	
	@Before("@BetaApp")
    public void beforeBetaAppInstall() throws MalformedURLException{
        System.out.println("This will run only before the First Scenario");
        
        
        DesiredCapabilities capabilities = new DesiredCapabilities();
		//capabilities.setCapability("browsername", "chrome");
		capabilities.setCapability("deviceName", "RZ8M42NP8GF");
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("appPackage", "io.crash.air");
		capabilities.setCapability("appActivity", "io.crash.air.ui.MainActivity");
		CommonMethods.driver = new AppiumDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		
		CommonMethods.driver.manage().timeouts().implicitlyWait(2, TimeUnit.MINUTES);
		
    } 
	
	@Before("@KoneApp")
    public void beforeKoneApp() throws MalformedURLException{
        System.out.println("This will run only before the Kone Scenario");
        
        
        DesiredCapabilities capabilities = new DesiredCapabilities();
		//capabilities.setCapability("browsername", "chrome");
		capabilities.setCapability("deviceName", "RZ8M42NP8GF");
		capabilities.setCapability("noReset","true");
		capabilities.setCapability("fullReset","false");
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("appPackage", "com.salesforce.fieldservice.app.kone.qa");
		//capabilities.setCapability("appActivity", "com.salesforce.fieldservice.app.splash.SplashScreenActivity");
		capabilities.setCapability("appActivity", "com.salesforce.fieldservice.app.launcher.FieldServicePrerequisiteActivity");
		CommonMethods.driver = new AppiumDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		
		CommonMethods.driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
    } 
	
	
	@After(order=0)
	 public static void writeExtentReport() {
	 Reporter.loadXMLConfig(new File(CommonMethods.getReportConfigPath()));
	 //CommonMethods.driver.quit();
	 }
	
	/*@After(order=1)
	public void afterScenario(Scenario scenario) {
		if (scenario.isFailed()) {
			String screenshotName = scenario.getName().replaceAll(" ", "_");
			try {
				// This takes a screenshot from the driver at save it to the specified location
				File sourcePath = ((TakesScreenshot) CommonMethods.driver).getScreenshotAs(OutputType.FILE);

				// Building up the destination path for the screenshot to save
				// Also make sure to create a folder 'screenshots' with in the cucumber-report
				// folder
				File destinationPath = new File(System.getProperty("user.dir") + "/target/cucumber-reports/screenshots/"
						+ screenshotName + ".png");

				// Copy taken screenshot from source location to destination location
				Files.copy(sourcePath, destinationPath);

				// This attach the specified screenshot to the test
				Reporter.addScreenCaptureFromPath(destinationPath.toString());
			} catch (IOException e) {

			}
		}
	}*/
	
	
	
}
