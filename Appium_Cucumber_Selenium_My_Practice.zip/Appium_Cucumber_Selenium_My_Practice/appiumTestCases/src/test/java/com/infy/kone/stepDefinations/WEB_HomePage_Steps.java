package com.infy.kone.stepDefinations;

import org.junit.Assert;

import com.infy.kone.objectRepository.WEB_HomePage_Objects;
import com.infy.kone.objectRepository.WEB_LoginPage_Objects;
import com.infy.kone.utility.CommonMethods;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WEB_HomePage_Steps {

	CommonMethods commonMethods = new CommonMethods();


	@Then("^User navigates to FSM page$")
	public void user_navigates_to_FSM_page() throws Throwable {
		
		Assert.assertTrue("Home page not loaded", commonMethods.isElementDisplayed(WEB_HomePage_Objects.textbox_Search));
	 
	}

	@Then("^User search for equipment$")
	public void user_search_for_equipment() throws Throwable {
	   
		commonMethods.clickOnElement(WEB_HomePage_Objects.dropdown_allOptions);
	
	}

	@When("^User creates case with automatic dispatching$")
	public void user_creates_case_with_automatic_dispatching() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user verify the technician as \"([^\"]*)\"$")
	public void user_verify_the_technician_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  
	}

	@When("^user Dispatch the Service Appointment$")
	public void user_Dispatch_the_Service_Appointment() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	
	}

	@Then("^verify Service Appointment is dispatched$")
	public void verify_Service_Appointment_is_dispatched() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  
	}

	
}
