package com.infy.kone.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.google.common.io.Files;

import cucumber.api.Scenario;
import io.appium.java_client.FindsByAndroidUIAutomator;
import io.appium.java_client.MobileElement;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

/**
 * @author sangram.jadhav01
 *
 */
public class CommonMethods {

	public static WebDriver driver;
	public static Properties prop;
	public static Logger log=Logger.getLogger(CommonMethods.class);
	WebDriverWait wait;
   
	 
 
	
	
	
	/**
	 *  This method loads all the properties from config.properties. Called this method in Before Hooks
	 */
	public static void loadProperties() {
		File file = new File("Test_Data/config.properties");
		try {
			FileInputStream fin = new FileInputStream(file);
			prop = new Properties();
			prop.load(fin);
			log.info("Property files are loaded successfully!!!!");
		
		} catch (IOException e) {
			
			log.info("property files not loaded properly. Please check path mentioned");
		}
	}
	
	
	/**
	 * Below method returns value of path of extent-config.xml file
	 * @return value of path of extent-config.xml
	 * @author sangram.jadhav01
	 */
	public static String getReportConfigPath() {
		String reportConfigPath = prop.getProperty("reportConfigPath");
		if (reportConfigPath != null)
			return reportConfigPath;
		else
			throw new RuntimeException(
					"Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");
	}

	
	
	
	/**
	 * Below method is entry point of test case execution. 
	 * @param browser
	 * @param app_url
	 * @author sangram.jadhav01
	 */
	public void openApplication(String browser, String app_url) {
		
		try {
			
		switch (browser) {
		case "firefox":
			driver = new FirefoxDriver();
			break;
		case "chrome":
			System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
			driver = new ChromeDriver();
			break;
		case "IE":
			driver = new InternetExplorerDriver();
			break;
		default:
			System.out.println("browser : " + browser + " is invalid, Launching Firefox as browser of choice..");
			driver = new FirefoxDriver();
			
		}
		
		driver.get(prop.getProperty(app_url));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}
		
		catch(Exception e) {
			log.info(e);
		}
	}
	
	
	
	/**
	 *  This method takes screenshot. You need to call this at end of every step level to capture screenshot of each step.
	 *  Pass parameter as Step Name. (i.e Method name )
	 *   If we need Screenshots to be taken for Failed scenario's only then we have written method in @After hook
	 * @param stepName
	 * @return
	 * @author Sangram Jadhav
	 */
	
	public static String takeScreenshot(String stepName) {
		
		String screenshotFile = null;
		try {
			 //This takes a screenshot from the driver at save it to the specified location
			
			File sourcePath=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			
			 //Building up the destination path for the screenshot to save
			 //Also make sure to create a folder 'screenshots' with in the cucumber-report folder
			String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());  
			 File destinationPath = new File(System.getProperty("user.dir") + "/target/cucumber-reports/screenshots/" + stepName + timeStamp+".png");
			 
			 screenshotFile=destinationPath.toString();
			 //Copy taken screenshot from source location to destination location
			 Files.copy(sourcePath, destinationPath);   
			 
			 
		}
		catch(IOException e) {
			
		}
		return screenshotFile;
	}
	
	

	
	
	
	/**
	 *  Method verifies element is displayed or not
	 * @param locator
	 * @return True if element is displayed
	 * @author sangram.jadhav01
	 */
	public boolean isElementDisplayed(By locator) {

		boolean elementDisplayed = false;
		List<WebElement> list = new ArrayList<>();

		try {
			list = driver.findElements(locator);
			if (list.size() > 0) {
				elementDisplayed = list.get(0).isDisplayed();
				log.info(locator + "is displayed in DOM");
			}
			else {
				log.info(locator + "is not displayed in DOM");
			}
		}

		catch (Exception e) {
			log.error(e);

		}
		return elementDisplayed;
	}
	
	/**Below method will select dropdown value from list
	 * 
	 * 
	 * @param dropdownValue
	 * @param locator
	 * @author sangram.jadhav01
	 */
	public void selectDropdownOptionByText(String dropdownValue, By locator) {
		
		try {
			if(isElementDisplayed(locator)) {
			
		    WebElement dropDown = driver.findElement(locator);
			Select option = new Select(dropDown);
			option.selectByVisibleText(dropdownValue);
			}
			
			else {
				log.info("Dropdown element is not displayed");
			}
		}
		catch(Exception e) {
			
			log.error(e);
		}
		
	}
	
	
	// Below method is for enter text in texbox
	public void enterValue(By locator ,String value) {
		if (isElementDisplayed(locator)) {
			driver.findElement(locator).sendKeys(value);
		}
		else {
			log.info("Value not entered in "+locator);
		}
	}
	
	
	public void clickOnElement(By locator) {

		
		if(isElementDisplayed(locator)) {
			
		driver.findElement(locator).click();
		}
		else {
			Assert.assertTrue(isElementDisplayed(locator), locator +" is not clicked");
			log.info(locator + " is not clicked ");
		}
	}
	
	
	
	public void sleepWait() throws InterruptedException {
		Thread.sleep(30000);
	}
	
	
	public void waitForElementIsDisplayed(By locator) throws InterruptedException {
		
		try {	
			WebDriverWait wait = new WebDriverWait(CommonMethods.driver, 120);
		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		
		}
		catch(ElementNotVisibleException e) {
			
		}
		
	}
	
	

	
	
	public void getListOfElements(By locator) {
		
		List<WebElement> list = driver.findElements(locator);
		System.out.println("total elements - "+ list.size());
		
		for(WebElement element:list) {
			WebElement InsideFirstelement =element.findElement(By.xpath("//android.widget.LinearLayout")).findElement(By.xpath("android.widget.TextView"));
			String text =InsideFirstelement.getText();
			System.out.println("Text version is - "+text);
			
		}
		
	}
	
	
	
	/** This method do scrolling by the 20% of the height of screen at single time and starts scrolling at middle of the screen
	 * If we need multiple scroll on the screen in that case use this methid with While loop and give condition of display of any element or size of element
	 * 
	 * e.g we can use this method as below
	 *  
	 * List<WebElement> acceptedStatusList = new ArrayList<WebElement>();

		while(commonMethods.listOfElements(Locator).size()==0) {
			commonMethods.scrollDownTillElement_mobile();
			acceptedStatusList=commonMethods.listOfElements(Locator);
		}
		acceptedStatusList.get(0).click();
	 * 
	 * 
	 */
	public  void scrollDownTillElement_mobile() {
		Dimension dimension = driver.manage().window().getSize();
		
		Double scrollHeightStart = dimension.getHeight() * 0.5;
		int scrollStart = scrollHeightStart.intValue();
		
		Double scrollHeightEnd = dimension.getHeight() * 0.2;
		int scrollEnd = scrollHeightEnd.intValue();
		
		new TouchAction((PerformsTouchActions) driver)
		.press(PointOption.point(0, scrollStart))
		.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2)))
		.moveTo(PointOption.point(0, scrollEnd))
		.release().perform();
	}
	
/*	
	public void scrollToViewElement_mobile(By locator) {
		while(!(isElementDisplayed(locator))) {
			scrollDownTillElement_mobile();
		}
			
	}*/
	


	
	
	/**
	 * @param locator
	 * @param elementText
	 * @return WebElement
	 * @author sangram.jadhav01
	 */
	public WebElement selectElementFromListByName(By locator,String elementText) {
		
		List<WebElement>list =driver.findElements(locator);
		WebElement element =null;
		
		for (WebElement ListElement :list) {
			if(ListElement.getText().equals(elementText)) {
				 element=ListElement;
			}
		}
		return element;
		
	}
	
	
	
	/**
	 * @param locator
	 * @return method returns the list of element
	 * @author sangram.jadhav01
	 */
	public List<WebElement> listOfElements(By locator) {
		List<WebElement>list =driver.findElements(locator);
		return list;
	}
	
	
	/**
	 * @param locator
	 * @return Element text if element is deisplayed on DOM
	 * @author sangram.jadhav01
	 */
	public String getTextOfElement(By locator) {
		
		String text= null;
		
		try {
		if(isElementDisplayed(locator)) {
			text=driver.findElement(locator).getText();
		}
		
		}
		catch (NoSuchElementException e) {
			log.info(e);
		}
		return text;
	}
	
	
	
}
