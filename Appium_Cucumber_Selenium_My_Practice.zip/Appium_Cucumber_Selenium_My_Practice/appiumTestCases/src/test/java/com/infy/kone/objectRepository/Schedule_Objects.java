package com.infy.kone.objectRepository;

import org.openqa.selenium.By;

public class Schedule_Objects {

	//public static final By list_siteVisits=By.xpath("//android.widget.TextView[contains(@resource-id,'status')]");
	//public static final By list_siteVisits=By.xpath("//android.widget.TextView[contains(@resource-id,'status') and @text='Accepted']");
	public static final By list_siteVisits=By.xpath("//android.widget.TextView[@text='Accepted']");
	public static final By link_Schedule = By.xpath("//android.widget.FrameLayout[@content-desc='Schedule tab']/android.widget.RelativeLayout");
	public static final By button_NextAction=By.xpath("//android.widget.Button[@text='NEXT ACTION']");
	//public static final By button_OnRoute=By.xpath("//android.widget.TextView[@text='Onderweg']");
	public static final By button_OnRoute=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup/android.widget.TextView");
	public static final By text_SiteVisitStatus=By.id("status");
	public static final By button_CancelNavigation=By.xpath("//android.widget.TextView[@text='CANCEL']");
	public static final By button_Arrived=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.widget.TextView");
	public static final By button_NextStep=By.xpath("//android.widget.TextView[@text='NEXT STEP']");
	public static final By button_SelectCode=By.xpath("//android.widget.TextView[contains(@text,'NORMAAL')]");
	

	
	
}
