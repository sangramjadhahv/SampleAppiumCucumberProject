package com.infy.kone.objectRepository;

import org.openqa.selenium.By;

public class WEB_LoginPage_Objects {

	public static final By textbox_userName=By.xpath("//*[@id='username']");
	public static final By textbox_password=By.xpath("//*[@id='password']");
	public static final By button_login=By.xpath("//*[@id='Login']");
	public static final By popup_ok=By.xpath("//button[@id='ext-gen25']");
	
}
