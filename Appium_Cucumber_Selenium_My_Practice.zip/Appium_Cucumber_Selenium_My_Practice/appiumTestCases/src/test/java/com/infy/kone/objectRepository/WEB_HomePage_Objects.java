package com.infy.kone.objectRepository;

import org.openqa.selenium.By;

public class WEB_HomePage_Objects {

	
	public static final By textbox_Search=By.id("phSearchInput");
	public static final By dropdown_allOptions=By.xpath("//em[@id='ext-gen149']");
	
	
}
