package com.infy.kone.objectRepository;

import org.openqa.selenium.By;

public class LoginPage_Objects {

	public static final By three_dots=By.xpath("//android.widget.ImageButton[@content-desc='More options']");
	public static final By Test_server=By.xpath("/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RadioGroup/android.widget.RadioButton[2]");
	public static final By change_server=By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[1]/android.widget.RelativeLayout/android.widget.TextView");
	public static final By Apply_btn=By.id("com.salesforce.fieldservice.app.kone.qa:id/sf__apply_button");
	
	
	public static final By textbox_userName=By.id("usernamegroup");
	public static final By textbox_password=By.id("password");
	public static final By btn_login=By.id("Login");
	public static final By btn_allow=By.xpath("//android.widget.Button[@text='Toestaan']");
	public static final By text_sync=By.xpath("//android.widget.TextView[@text='Sync']");
	public static final By btn_allowAccessLocation=By.xpath("//android.widget.Button[@text='ALLOW']");
	public static final By switch_DNDPermission=By.xpath("//android.widget.TextView[@text='QA Kone Field Service']");
	public static final By btn_AllowDND=By.id("button1");
	public static final By back_arrow=By.xpath("//android.widget.ImageButton[@content-desc='Navigate up']");
	
	
	
}