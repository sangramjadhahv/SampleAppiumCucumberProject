package com.infy.kone.runner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
 features = "Feature_Files"
 ,glue={"com.infy.kone.stepDefinations","com.infy.kone.utility"}
 ,plugin = { "com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html"}
 //,dryRun = true
 ,tags = {"@KoneApp"}
 ,
 // "pretty","html:target/cucumber-reports", "json:target/cucumber-reports/Cucumber.json",
// 
 monochrome = true
 )
 

public class TestRunner {
	
}
