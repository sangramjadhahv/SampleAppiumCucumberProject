package com.infy.kone.objectRepository;

import org.openqa.selenium.By;

public class Install_Objects {

	
	public static final By link_OK=By.xpath("//android.widget.TextView[@text='OK']");
	public static final By button_INSTALL=By.xpath("//android.widget.Button[@text='INSTALL']");
	public static final By button_OPEN=By.xpath("//android.widget.Button[@text='OPEN']");
	public static final By button_NEXT=By.xpath("//android.widget.Button[@text='NEXT']");
	
	// Kone App Install objects
	public static final By field_previousVersion=By.xpath("//android.widget.LinearLayout[@resource-id='io.crash.air:id/previous_build_left_side']");
	
	public static final By button_SeeMore=By.xpath("//android.widget.Button[@text='SEE MORE']");
	public static final By button_InstallOK=By.xpath("//android.widget.Button[@text='OK']");
}
