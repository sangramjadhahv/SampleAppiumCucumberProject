package com.infy.kone.pages;

import com.infy.kone.objectRepository.WEB_LoginPage_Objects;
import com.infy.kone.utility.CommonMethods;

public class WEB_Login_Page {

	
CommonMethods commonMethods = new CommonMethods();
	
	public void loginToAppliction() {
		
		commonMethods.enterValue(WEB_LoginPage_Objects.textbox_userName,CommonMethods.prop.getProperty("UserID_Int") );
		commonMethods.enterValue(WEB_LoginPage_Objects.textbox_password,CommonMethods.prop.getProperty("Password_Int") );
		commonMethods.clickOnElement(WEB_LoginPage_Objects.button_login);
		commonMethods.clickOnElement(WEB_LoginPage_Objects.popup_ok);
		
	}
}
