package com.infy.kone.stepDefinations;

import org.junit.Assert;

import com.infy.kone.objectRepository.WEB_LoginPage_Objects;
import com.infy.kone.pages.WEB_Login_Page;
import com.infy.kone.utility.CommonMethods;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class WEB_LoginPage_Steps {

	CommonMethods commonMethods = new CommonMethods();
	WEB_Login_Page loginPage= new WEB_Login_Page();

	@Given("^User is on Home Page$")
	public void user_is_on_Home_Page() throws Throwable {
	
		commonMethods.openApplication("chrome", "int_url");
	  Assert.assertTrue("Home page not displayed", commonMethods.isElementDisplayed(WEB_LoginPage_Objects.textbox_userName));
	}

	@When("^User enters login details$")
	public void user_enters_UserName_and_Password() throws Throwable {
	    
		loginPage.loginToAppliction();
	 
	}
	
}
