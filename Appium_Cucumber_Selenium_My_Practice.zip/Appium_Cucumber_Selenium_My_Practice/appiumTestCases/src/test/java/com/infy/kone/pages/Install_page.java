package com.infy.kone.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.infy.kone.utility.CommonMethods;

public class Install_page {

	
	

	CommonMethods comMethods = new CommonMethods();
	public List<WebElement> getVersionsList(){
		//return driver.findElements(By.xpath("//android.widget.LinearLayout[@index="+1+"]"));
		
		return CommonMethods.driver.findElements(By.xpath("//android.widget.LinearLayout[@index='1']//android.widget.LinearLayout[@index='0']//android.widget.Button[@text='DOWNLOAD']"));
		
	}
	
	public void versionClick(String version) throws InterruptedException{
		WebElement downloadLink = null;
		
		scrollTillWebView();

		for (int i = 1; i < 100; i++) {
			System.out.println("Printing loop value :- " + i);
			WebElement element = CommonMethods.driver.findElement(By.xpath("//android.widget.LinearLayout[@index=" + i
					+ "]//android.widget.LinearLayout[@index='0']//android.widget.LinearLayout[@resource-id='io.crash.air:id/previous_build_left_side']//android.widget.LinearLayout[@index='0']//android.widget.TextView[@resource-id='io.crash.air:id/previous_build_version']"));

			String versionLabel = element.getText();
			System.out.println("LAbel value is : -" + versionLabel);
			if (element.getText().contains(version)) {

				downloadLink = CommonMethods.driver.findElement(By.xpath("//android.widget.LinearLayout[@index=" + i
						+ "]//android.widget.LinearLayout[@index='0']//android.widget.Button[@resource-id='io.crash.air:id/previous_build_install_button']"));
				downloadLink.click();
				break;
			}
		}
	}
	
	public void scrollTillWebView() throws InterruptedException {
		//getPreviousVersionLable
		//getVersionsList
		// getVersionsList().size()== 0
		System.out.println("Version list size is -"+getVersionsList().size());
		comMethods.scrollDownTillElement_mobile();
		while(getVersionsList().size()>2) {
			comMethods.scrollDownTillElement_mobile();
			System.out.println("size of list is :- "+getVersionsList().size());
		}
		
	}
	
	
	public void clickIfDisplayed(By locator) {
		if(comMethods.isElementDisplayed(locator)) {
			comMethods.clickOnElement(locator);
		}
		
		
	}
}
