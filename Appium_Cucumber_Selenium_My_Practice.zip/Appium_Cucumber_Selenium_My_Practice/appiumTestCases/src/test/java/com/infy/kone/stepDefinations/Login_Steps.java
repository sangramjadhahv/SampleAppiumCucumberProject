package com.infy.kone.stepDefinations;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.infy.kone.objectRepository.LoginPage_Objects;
import com.infy.kone.pages.Login_page;
import com.infy.kone.utility.CommonMethods;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class Login_Steps {

	CommonMethods commonMethods= new CommonMethods();
	String stepName;
	Login_page loginPage = new Login_page();
	
	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
	  Assert.assertTrue( commonMethods.isElementDisplayed(LoginPage_Objects.textbox_userName));
	}
	
	@Given("^User selects server as Test$")
	public void user_selects_server_as_Test() throws Throwable {
	 	
		loginPage.selectServer();
	}

	@When("^User enters username \"([^\"]*)\" password \"([^\"]*)\"$")
	public void user_enters_username_password(String arg1, String arg2) throws Throwable {
		loginPage.login();
	    
	}

	@When("^User clicks on Login button$")
	public void user_clicks_on_Login_button() throws Throwable {
	   
		commonMethods.sleepWait();
	 
	   commonMethods.clickOnElement(LoginPage_Objects.btn_allow);
	   Reporter.addStepLog(" Login done successfully!!");
	}

	@Then("^verify synch is started$")
	public void verify_synch_is_started() throws Throwable {
		loginPage.loginSuccessful();
		
	}
}
