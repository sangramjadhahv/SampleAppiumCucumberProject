package com.infy.kone.stepDefinations;

import org.testng.Assert;

import com.infy.kone.objectRepository.Schedule_Objects;
import com.infy.kone.pages.Schedule_page;
import com.infy.kone.utility.CommonMethods;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Schedule_Steps {

	CommonMethods commonMethods = new CommonMethods();
	Schedule_page schedule_page = new Schedule_page();
	
	
	@Then("^user land on schedule page$")
	public void user_land_on_schedule_page() throws Throwable {
	   
		commonMethods.waitForElementIsDisplayed(Schedule_Objects.link_Schedule);
		Assert.assertTrue(commonMethods.isElementDisplayed(Schedule_Objects.link_Schedule), "Element is not displayed");
		
	}
	@When("^User verify Service Appointment should be present in \"([^\"]*)\" status$")
	public void user_verify_Service_Appointment_should_be_present_in_status(String SiteVisitStatus) throws Throwable {
		schedule_page.scrollToSiteVisitAndClick(Schedule_Objects.list_siteVisits);
		//commonMethods.selectElementFromListByName(Schedule_Objects.list_siteVisits, SiteVisitStatus).click();
	}

	@When("^User Complete the Service appointment$")
	public void user_Complete_the_Service_appointment() throws Throwable {
		schedule_page.completeSiteVisit();
	}

	@Then("^User verify appointment is completed$")
	public void user_verify_appointment_is_completed() throws Throwable {
	   
	  
	}


}
