package com.infy.kone.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.infy.kone.objectRepository.Schedule_Objects;
import com.infy.kone.utility.CommonMethods;

public class Schedule_page {

	CommonMethods commonMethods = new CommonMethods();
	
	
	public void scrollToSiteVisitAndClick(By Locator) {

		List<WebElement> acceptedStatusList = new ArrayList<WebElement>();

		if (commonMethods.listOfElements(Locator).size() == 0) {
			
			while (commonMethods.listOfElements(Locator).size() == 0) {
				commonMethods.scrollDownTillElement_mobile();
				acceptedStatusList = commonMethods.listOfElements(Locator);
				
			}
		} else if(commonMethods.listOfElements(Locator).size() ==1){
			acceptedStatusList = commonMethods.listOfElements(Locator);
			
		}

		acceptedStatusList.get(0).click();
		
	}
	
	
	
	public void completeSiteVisit() throws InterruptedException {
		
		commonMethods.clickOnElement(Schedule_Objects.button_NextAction);
		
		Assert.assertTrue(commonMethods.isElementDisplayed(Schedule_Objects.button_OnRoute), "Site visit status ON Route page not displayed");
		commonMethods.clickOnElement(Schedule_Objects.button_OnRoute);
		
		Assert.assertTrue(commonMethods.isElementDisplayed(Schedule_Objects.button_CancelNavigation), "Cancel navigation pop us not displayed");
		commonMethods.clickOnElement(Schedule_Objects.button_CancelNavigation);
		
		commonMethods.sleepWait();
		
		Assert.assertTrue(commonMethods.getTextOfElement(Schedule_Objects.text_SiteVisitStatus).contains("ROUTE"),
				"Site visit staus has not changed to Route and current status is -"
						+ commonMethods.getTextOfElement(Schedule_Objects.text_SiteVisitStatus));
		commonMethods.clickOnElement(Schedule_Objects.button_NextAction);

		Assert.assertTrue(commonMethods.isElementDisplayed(Schedule_Objects.button_Arrived), "Site visit status Arrived page not displayed");
		commonMethods.clickOnElement(Schedule_Objects.button_Arrived);
		
		Assert.assertTrue(commonMethods.isElementDisplayed(Schedule_Objects.button_NextStep), "Element is not displayed");
		commonMethods.clickOnElement(Schedule_Objects.button_NextStep);
		
		Assert.assertTrue(commonMethods.isElementDisplayed(Schedule_Objects.button_SelectCode), "Code selection page is not displayed");
		commonMethods.clickOnElement(Schedule_Objects.button_SelectCode);
		
		
	}
	
}
