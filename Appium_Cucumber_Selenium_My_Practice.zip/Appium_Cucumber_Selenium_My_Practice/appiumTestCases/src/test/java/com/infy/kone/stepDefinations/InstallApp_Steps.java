package com.infy.kone.stepDefinations;

import com.cucumber.listener.Reporter;
import com.infy.kone.objectRepository.Install_Objects;
import com.infy.kone.pages.Install_page;
import com.infy.kone.utility.CommonMethods;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class InstallApp_Steps {

	String stepName;
	CommonMethods commonMethods= new CommonMethods();
	Install_page intPage = new Install_page();
	

	@Given("^User opens Beta App and clicks on OK button for Installing$")
	public void user_opens_Beta_App_and_clicks_on_OK_button_for_Installing() throws Throwable {
		//commonMethods.waitForElementIsDisplayed(Install_Objects.link_OK);
	
		commonMethods.clickOnElement(Install_Objects.link_OK);
		stepName=new Object() {} .getClass().getEnclosingMethod().getName();
		Reporter.addScreenCaptureFromPath(CommonMethods.takeScreenshot(stepName));
		
	}

	@When("^User clicks on INSTALL button$")
	public void user_clicks_on_INSTALL_button() throws Throwable {
		//commonMethods.waitForElementIsDisplayed(Install_Objects.button_INSTALL);
		commonMethods.clickOnElement(Install_Objects.button_INSTALL);
		stepName=new Object() {} .getClass().getEnclosingMethod().getName();
		Reporter.addScreenCaptureFromPath(CommonMethods.takeScreenshot(stepName));
	}

	@When("^User click on OPEN button$")
	public void user_clicka_on_OPEN_button() throws Throwable {
		//commonMethods.waitForElementIsDisplayed(Install_Objects.button_OPEN);
		commonMethods.clickOnElement(Install_Objects.button_OPEN);
		stepName=new Object() {} .getClass().getEnclosingMethod().getName();
		Reporter.addScreenCaptureFromPath(CommonMethods.takeScreenshot(stepName));
		
	}
	
	@When("^User click on Next button on start testing screen$")
	public void user_click_on_Next_button_on_start_testing_screen() throws Throwable {
	
		commonMethods.clickOnElement(Install_Objects.button_NEXT);
		stepName=new Object() {} .getClass().getEnclosingMethod().getName();
		Reporter.addScreenCaptureFromPath(CommonMethods.takeScreenshot(stepName));
	}
	    

	@When("^User click on download link for \"([^\"]*)\"$")
	public void user_click_on_download_link_for(String buildNumber) throws Throwable {
	  
		intPage.versionClick(buildNumber);
		stepName=new Object() {} .getClass().getEnclosingMethod().getName();
		Reporter.addScreenCaptureFromPath(CommonMethods.takeScreenshot(stepName));
		
		
		//commonMethods.getListOfElements(Install_Objects.field_previousVersion);
	}

	@When("^User clicks on OK button on popup for Kone App download$")
	public void user_clicks_on_OK_button_on_popup_for_Kone_App_download() throws Throwable {
	  
		commonMethods.clickOnElement(Install_Objects.button_INSTALL);
		commonMethods.sleepWait();
		stepName=new Object() {} .getClass().getEnclosingMethod().getName();
		Reporter.addScreenCaptureFromPath(CommonMethods.takeScreenshot(stepName));
	}

	@Then("^verify downloading is started$")
	public void verify_downloading_is_started() throws Throwable {
		//commonMethods.clickOnElement(Install_Objects.button_INSTALL);
		//commonMethods.sleepWait();
		
		
		commonMethods.clickOnElement(Install_Objects.button_OPEN);
		
		commonMethods.sleepWait();
		stepName=new Object() {} .getClass().getEnclosingMethod().getName();
		//Reporter.addScreenCaptureFromPath(CommonMethods.takeScreenshot(stepName));
		
	}
}
